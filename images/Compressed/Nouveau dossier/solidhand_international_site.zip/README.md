# Site Web Officiel de SolidHand International

Ce dépôt contient le site internet multipage de l'ONG **SolidHand International**, ancrée à **Agbata, Togo**.

## Structure du site

- `index.html` : Page d'accueil, repères confirmés et présentation synthétique.
- `actions.html` : Les 4 axes d'intervention (Formation, Soutien communautaire, Entrepreneuriat, Équipement) et indicateurs de suivi.
- `ancrage.html` : Ancrage local à Agbata (Togo) et démarche de proximité.
- `mission.html` : Histoire, principes fondamentaux et équipe complète.
- `transparence.html` : Engagements d'honnêteté financière et emplacements pour les futurs documents administratifs/PDF.
- `rejoindre.html` : Les 4 formes d'engagement (bénévolat, compétences, partenariats, soutiens) et FAQ.
- `contact.html` : Coordonnées publiques vérifiées, lien WhatsApp direct et formulaire.
- `css/styles.css` : Feuille de style globale (charte graphique vert forêt / marron terre / crème).
- `js/main.js` : Script JavaScript principal (menu mobile, accordéon FAQ, gestion du formulaire).

## Instructions d'intégration ultérieure

### 1. Photos du terrain
Déposez les nouvelles photos prises à Agbata à la racine ou dans un dossier `images/`, puis remplacez les blocs de réserve (`<div class="placeholder-image">`) par vos balises HTML :
```html
<img src="images/terrain-agbata.jpg" alt="Atelier de formation à Agbata" class="img-responsive">
```

### 2. Ajout des rapports d'activité (PDF)
Pour publier un document officiel validé (dans `transparence.html`) :
1. Créez un dossier `docs/` à la racine.
2. Ajoutez votre fichier PDF (ex: `rapport-2026.pdf`).
3. Remplacez le texte `Document à publier` par le lien suivant :
```html
<a href="docs/rapport-2026.pdf" class="btn btn-primary" download>Télécharger (PDF)</a>
```

## Contact Administratif
- **Courriel :** yaogalley2024@gmail.com
- **WhatsApp :** +1 (401) 441-1651
- **Localisation :** Agbata, Togo
